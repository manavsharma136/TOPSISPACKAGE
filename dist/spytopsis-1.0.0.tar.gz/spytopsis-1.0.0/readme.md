TOPSIS
A Python package to get topsis result

Usage
Following query on terminal will provide you the topsis detail.
Usages: python topsis.py <InputDataFile> <Weights> <Impacts>
